package com.example.huiswerk_les10_techiteasy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HuiswerkLes10TechiteasyApplication {

    public static void main(String[] args) {
        SpringApplication.run(HuiswerkLes10TechiteasyApplication.class, args);
    }



        }