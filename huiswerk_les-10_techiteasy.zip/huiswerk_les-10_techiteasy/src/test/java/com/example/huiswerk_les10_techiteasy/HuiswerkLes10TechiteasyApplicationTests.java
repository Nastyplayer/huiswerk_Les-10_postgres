package com.example.huiswerk_les10_techiteasy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HuiswerkLes10TechiteasyApplicationTests {

    @Test
    void contextLoads() {
    }

}
